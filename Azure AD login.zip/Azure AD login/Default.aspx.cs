﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.DirectoryServices.Protocols;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;


public partial class _Default : System.Web.UI.Page
{
    bool isValid = false;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        try
        {
            lblmsg.Text = "";
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, "elevate.loc"))
            {
                // validate the credentials
                isValid = pc.ValidateCredentials(txtusername.Text, txtpassword.Text);
            }
            if (isValid == true)
            {
                lblmsg.Text = "Logged in";
            }
            else
            {
                lblmsg.Text = "incorrect username/password";
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
       
    }
}